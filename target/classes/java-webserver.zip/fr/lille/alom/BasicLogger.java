package fr.lille.alom;

/** Logs to System.err */
public class BasicLogger {
  public void log (String msg) { System.err.println(msg); }
}
