package fr.lille.alom;

public enum RequestType {
	GET, POST;
}
